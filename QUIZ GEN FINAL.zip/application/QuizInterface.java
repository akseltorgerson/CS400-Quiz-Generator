package application;

public interface QuizInterface {

     void addQuestion(Question question) ;


    void getQuestions(String topicName, int numQuestions);


    void randomizeQuestionList();


}
