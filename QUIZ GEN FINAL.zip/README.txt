A-Team 72

Parker Schroeder	ptschroeder@wisc.edu
Dylan Clark		daclark@wisc.edu
Zachary Chanak		chanak@wisc.edu
Jacob Mayl		mayl@wisc.edu
Aksel Torgerson		atorgerson@wisc.edu


